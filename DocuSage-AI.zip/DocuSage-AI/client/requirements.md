## Packages
react-dropzone | For drag-and-drop file uploads
framer-motion | For smooth UI transitions and loading states
react-markdown | To render markdown formatting in AI answers
date-fns | For formatting dates

## Notes
API endpoints defined in shared/routes.ts will be used.
File upload uses FormData.
UI focuses on a clean, documentation-style aesthetic.
