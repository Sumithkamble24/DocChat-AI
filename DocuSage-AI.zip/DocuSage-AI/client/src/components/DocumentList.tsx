import { useDocuments } from "@/hooks/use-rag";
import { FileText, CheckCircle2, Clock } from "lucide-react";
import { motion } from "framer-motion";

export function DocumentList() {
  const { data: documents, isLoading, error } = useDocuments();

  if (isLoading) {
    return (
      <div className="space-y-3 mt-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-12 bg-muted/50 rounded-lg animate-pulse" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 rounded-lg bg-destructive/10 text-destructive text-sm mt-4">
        Failed to load documents
      </div>
    );
  }

  if (!documents?.length) {
    return (
      <div className="flex flex-col items-center justify-center py-10 px-4 text-center border rounded-xl border-dashed mt-4 bg-muted/10">
        <FileText className="h-8 w-8 text-muted-foreground/50 mb-3" />
        <p className="text-sm font-medium text-foreground">No documents yet</p>
        <p className="text-xs text-muted-foreground mt-1">
          Upload a PDF to start chatting
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2 mt-4">
      <div className="flex items-center justify-between mb-2 px-1">
        <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          Knowledge Base
        </h4>
        <span className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded-md">
          {documents.length}
        </span>
      </div>
      
      <div className="max-h-[300px] overflow-y-auto pr-1 space-y-2 scrollbar-thin">
        {documents.map((doc, idx) => (
          <motion.div
            key={doc.filename}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="group flex items-center justify-between p-3 rounded-lg border border-border/50 bg-card hover:bg-secondary/50 hover:border-border transition-all duration-200"
          >
            <div className="flex items-center min-w-0">
              <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center text-primary mr-3 flex-shrink-0">
                <FileText className="h-4 w-4" />
              </div>
              <div className="truncate">
                <p className="text-sm font-medium truncate text-foreground/90 group-hover:text-primary transition-colors">
                  {doc.filename}
                </p>
                <div className="flex items-center text-[10px] text-muted-foreground mt-0.5">
                  {doc.processed ? (
                    <span className="flex items-center text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Indexed
                    </span>
                  ) : (
                    <span className="flex items-center text-amber-600 dark:text-amber-400">
                      <Clock className="w-3 h-3 mr-1" />
                      Processing
                    </span>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
