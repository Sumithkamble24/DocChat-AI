import { useState, useRef, useEffect } from "react";
import { useQueryKnowledgeBase } from "@/hooks/use-rag";
import { Send, Sparkles, Bot, User, Quote, ChevronRight } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { motion, AnimatePresence } from "framer-motion";

export function ChatInterface() {
  const [question, setQuestion] = useState("");
  const { mutate: ask, isPending, data: response, error } = useQueryKnowledgeBase();
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || isPending) return;
    ask(question);
  };

  return (
    <div className="flex flex-col h-full max-w-3xl mx-auto w-full">
      {/* Result Area */}
      <div className="flex-1 overflow-y-auto min-h-[400px] pb-6 space-y-6">
        <AnimatePresence mode="wait">
          {!response && !isPending && !error ? (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="h-full flex flex-col items-center justify-center text-center p-8 text-muted-foreground/60"
            >
              <div className="w-16 h-16 bg-gradient-to-tr from-primary/10 to-primary/5 rounded-2xl flex items-center justify-center mb-6 ring-1 ring-primary/10">
                <Sparkles className="w-8 h-8 text-primary/40" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Ask anything about your documents</h3>
              <p className="max-w-md mx-auto mb-8">
                The AI will analyze your uploaded PDFs and extract precise answers with source citations.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-lg">
                {["Summarize the key findings", "What are the main risks?", "Explain the methodology", "List the action items"].map((q) => (
                  <button
                    key={q}
                    onClick={() => {
                      setQuestion(q);
                      ask(q);
                    }}
                    className="text-xs text-left p-3 rounded-lg border hover:bg-secondary/50 hover:border-primary/30 transition-all duration-200"
                  >
                    "{q}"
                  </button>
                ))}
              </div>
            </motion.div>
          ) : (
            <div className="space-y-8 pt-4">
              {/* Question */}
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0 mt-1">
                  <User className="w-4 h-4 text-muted-foreground" />
                </div>
                <div className="flex-1 pt-1.5">
                  <h3 className="text-lg font-medium text-foreground">{question}</h3>
                </div>
              </div>

              {/* Error State */}
              {error && (
                 <div className="flex gap-4 p-4 rounded-xl bg-destructive/5 border border-destructive/20 text-destructive">
                   <div className="w-8 h-8 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0">
                     <Bot className="w-4 h-4" />
                   </div>
                   <div className="pt-1.5">
                     <p className="font-medium">Something went wrong</p>
                     <p className="text-sm opacity-90 mt-1">{(error as Error).message}</p>
                   </div>
                 </div>
              )}

              {/* Loading State */}
              {isPending && (
                <div className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1 ring-4 ring-primary/10">
                    <Bot className="w-4 h-4 text-primary-foreground animate-pulse" />
                  </div>
                  <div className="flex-1 space-y-3 pt-2">
                    <div className="h-4 bg-muted rounded w-3/4 animate-pulse" />
                    <div className="h-4 bg-muted rounded w-1/2 animate-pulse" />
                    <div className="h-4 bg-muted rounded w-5/6 animate-pulse" />
                  </div>
                </div>
              )}

              {/* Answer State */}
              {response && !isPending && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex gap-4"
                >
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1 shadow-lg shadow-primary/20">
                    <Sparkles className="w-4 h-4 text-primary-foreground" />
                  </div>
                  <div className="flex-1 space-y-6">
                    <div className="prose prose-sm md:prose-base dark:prose-invert max-w-none text-foreground leading-relaxed">
                      <ReactMarkdown>{response.answer}</ReactMarkdown>
                    </div>
                    
                    {response.sources.length > 0 && (
                      <div className="border-t pt-4 mt-6">
                        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
                          <Quote className="w-3 h-3" />
                          Sources
                        </h4>
                        <div className="space-y-2">
                          {response.sources.map((source, i) => (
                            <div 
                              key={i} 
                              className="group p-3 rounded-lg bg-secondary/30 border border-border/50 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary/60 hover:border-primary/20 transition-all duration-200"
                            >
                              <div className="flex gap-2.5">
                                <span className="font-mono text-xs text-primary/60 bg-primary/5 px-1.5 py-0.5 rounded flex-shrink-0 h-fit mt-0.5">
                                  {i + 1}
                                </span>
                                <p className="leading-snug line-clamp-3">{source}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* Input Area */}
      <div className="relative pt-4 pb-2">
        <form 
          onSubmit={handleSubmit}
          className="relative group"
        >
          <input
            ref={inputRef}
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question about your documents..."
            disabled={isPending}
            className="w-full pl-5 pr-14 py-4 rounded-2xl border bg-background shadow-lg shadow-black/5 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-base"
          />
          <button
            type="submit"
            disabled={!question.trim() || isPending}
            className={`
              absolute right-2 top-2 bottom-2 aspect-square rounded-xl flex items-center justify-center
              transition-all duration-200
              ${!question.trim() || isPending 
                ? "bg-secondary text-muted-foreground cursor-not-allowed opacity-50" 
                : "bg-primary text-primary-foreground shadow-md hover:shadow-lg hover:scale-105 active:scale-95"}
            `}
          >
            {isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </form>
        <p className="text-center text-[10px] text-muted-foreground mt-3">
          AI generated answers may be inaccurate. Please verify important information from sources.
        </p>
      </div>
    </div>
  );
}
