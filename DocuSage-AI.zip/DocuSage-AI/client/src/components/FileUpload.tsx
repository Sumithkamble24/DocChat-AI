import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, FileText, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { useUploadDocument } from "@/hooks/use-rag";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export function FileUpload() {
  const [isHovering, setIsHovering] = useState(false);
  const { mutate: uploadFile, isPending } = useUploadDocument();
  const { toast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast({
        title: "Invalid file type",
        description: "Please upload a PDF document.",
        variant: "destructive",
      });
      return;
    }

    uploadFile(file, {
      onSuccess: (data) => {
        toast({
          title: "Document processed",
          description: `Successfully indexed ${data.filename}`,
        });
      },
      onError: (error) => {
        toast({
          title: "Upload failed",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  }, [uploadFile, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    multiple: false,
    disabled: isPending
  });

  return (
    <div className="w-full">
      <div
        {...getRootProps()}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
        className={`
          relative overflow-hidden rounded-xl border-2 border-dashed p-8 text-center transition-all duration-300 cursor-pointer
          ${isDragActive || isHovering 
            ? "border-primary bg-primary/5 scale-[1.01] shadow-lg" 
            : "border-border bg-card hover:border-primary/50"}
          ${isPending ? "opacity-50 cursor-not-allowed pointer-events-none" : ""}
        `}
      >
        <input {...getInputProps()} />
        
        <AnimatePresence mode="wait">
          {isPending ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col items-center justify-center py-4"
            >
              <div className="relative">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
              </div>
              <p className="mt-4 text-sm font-medium text-foreground">Analyzing document structure...</p>
              <p className="text-xs text-muted-foreground mt-1">This creates embeddings for RAG</p>
            </motion.div>
          ) : (
            <motion.div
              key="idle"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col items-center justify-center py-2"
            >
              <div className={`p-4 rounded-full mb-4 transition-colors duration-300 ${isDragActive ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>
                <Upload className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold tracking-tight mb-1">Upload Knowledge Base</h3>
              <p className="text-sm text-muted-foreground mb-4 max-w-xs mx-auto">
                Drag & drop a PDF here, or click to select
              </p>
              <div className="inline-flex items-center text-xs font-medium text-muted-foreground bg-secondary/50 px-2 py-1 rounded-md border border-border/50">
                <FileText className="w-3 h-3 mr-1.5" />
                PDF only
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
