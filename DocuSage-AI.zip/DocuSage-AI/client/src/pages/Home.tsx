import { FileUpload } from "@/components/FileUpload";
import { DocumentList } from "@/components/DocumentList";
import { ChatInterface } from "@/components/ChatInterface";
import { BrainCircuit } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row overflow-hidden font-sans">
      {/* Sidebar - Mobile: Stacked, Desktop: Fixed Left */}
      <aside className="w-full md:w-[320px] lg:w-[360px] flex-shrink-0 bg-secondary/30 border-b md:border-b-0 md:border-r border-border h-auto md:h-screen overflow-y-auto">
        <div className="p-6 h-full flex flex-col">
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/20">
              <BrainCircuit className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-lg tracking-tight text-foreground">DocuMind AI</h1>
              <p className="text-xs text-muted-foreground font-medium">RAG Document Analysis</p>
            </div>
          </div>

          {/* Controls */}
          <div className="space-y-6 flex-1">
            <FileUpload />
            
            <div className="my-6 border-t border-border/50" />
            
            <DocumentList />
          </div>

          {/* Footer Info */}
          <div className="mt-8 pt-6 border-t border-border/50 text-xs text-muted-foreground">
            <p>Powered by Open Source LLMs</p>
            <p className="mt-1 opacity-50">Local Vector Store (FAISS)</p>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 h-screen overflow-hidden relative flex flex-col">
        {/* Top Navbar (only visible on mobile essentially as title is in sidebar) */}
        <div className="h-16 border-b md:hidden flex items-center px-6">
          <span className="font-semibold">Chat</span>
        </div>

        {/* Chat Canvas */}
        <div className="flex-1 w-full max-w-5xl mx-auto p-4 md:p-8 flex flex-col h-full">
          <ChatInterface />
        </div>
      </main>
    </div>
  );
}
