import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type QueryResponse } from "@shared/schema";

// GET /api/documents
export function useDocuments() {
  return useQuery({
    queryKey: [api.documents.path],
    queryFn: async () => {
      const res = await fetch(api.documents.path);
      if (!res.ok) throw new Error("Failed to fetch documents");
      // Validate with Zod schema from routes
      return api.documents.responses[200].parse(await res.json());
    },
  });
}

// POST /api/upload
export function useUploadDocument() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);

      const res = await fetch(api.upload.path, {
        method: api.upload.method,
        body: formData,
        // Don't set Content-Type header manually for FormData, let browser handle boundary
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Upload failed");
      }
      
      return api.upload.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      // Refresh the documents list after upload
      queryClient.invalidateQueries({ queryKey: [api.documents.path] });
    },
  });
}

// POST /api/query
export function useQueryKnowledgeBase() {
  return useMutation({
    mutationFn: async (question: string) => {
      // Validate input using Zod schema
      const payload = api.query.input.parse({ question });
      
      const res = await fetch(api.query.path, {
        method: api.query.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Query failed");
      }

      return api.query.responses[200].parse(await res.json());
    },
  });
}
