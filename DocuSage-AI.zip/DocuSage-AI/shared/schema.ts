import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  uploadDate: timestamp("upload_date").defaultNow(),
  processed: boolean("processed").default(false),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({ 
  id: true, 
  uploadDate: true,
  processed: true 
});

export const querySchema = z.object({
  question: z.string().min(1, "Question cannot be empty"),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export interface QueryResponse {
  answer: string;
  sources: string[];
}
