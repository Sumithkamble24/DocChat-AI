import { z } from 'zod';
import { insertDocumentSchema, documents, querySchema } from './schema';

export const api = {
  upload: {
    method: 'POST' as const,
    path: '/api/upload',
    input: z.any(), // FormData
    responses: {
      200: z.object({ message: z.string(), filename: z.string() }),
      400: z.object({ message: z.string() }),
    },
  },
  query: {
    method: 'POST' as const,
    path: '/api/query',
    input: querySchema,
    responses: {
      200: z.object({ answer: z.string(), sources: z.array(z.string()) }),
      500: z.object({ message: z.string() }),
    },
  },
  documents: {
    method: 'GET' as const,
    path: '/api/documents',
    responses: {
      200: z.array(z.object({ filename: z.string(), processed: z.boolean() })),
    },
  }
};
