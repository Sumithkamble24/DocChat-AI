import { type Document, type InsertDocument } from "@shared/schema";

export interface IStorage {
  // Documents
  createDocument(doc: InsertDocument): Promise<Document>;
  getDocuments(): Promise<Document[]>;
  // Simple in-memory text store for RAG simulation
  addDocumentText(filename: string, text: string): void;
  searchDocuments(query: string): Promise<{ text: string; source: string }[]>;
}

export class MemStorage implements IStorage {
  private documents: Map<number, Document>;
  private documentTexts: Map<string, string>;
  private currentId: number;

  constructor() {
    this.documents = new Map();
    this.documentTexts = new Map();
    this.currentId = 1;
  }

  async createDocument(insertDoc: InsertDocument): Promise<Document> {
    const id = this.currentId++;
    const doc: Document = { 
        ...insertDoc, 
        id, 
        uploadDate: new Date(), 
        processed: true 
    };
    this.documents.set(id, doc);
    return doc;
  }

  async getDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  addDocumentText(filename: string, text: string) {
    this.documentTexts.set(filename, text);
  }

  async searchDocuments(query: string): Promise<{ text: string; source: string }[]> {
    const results: { text: string; source: string }[] = [];
    const lowerQuery = query.toLowerCase();
    
    // Naive keyword search
    for (const [filename, text] of this.documentTexts.entries()) {
        const lowerText = text.toLowerCase();
        if (lowerText.includes(lowerQuery)) {
            // Extract a snippet around the match
            const index = lowerText.indexOf(lowerQuery);
            const start = Math.max(0, index - 100);
            const end = Math.min(text.length, index + 200);
            const snippet = text.substring(start, end) + "...";
            results.push({ text: snippet, source: filename });
        }
    }
    return results;
  }
}

export const storage = new MemStorage();
