import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import multer from "multer";
import * as pdfParseLib from "pdf-parse";

// Handle CommonJS import in ESM environment
// @ts-ignore
const pdfParse = pdfParseLib.default || pdfParseLib;

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Upload endpoint
  app.post(api.upload.path, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      if (req.file.mimetype !== 'application/pdf') {
        return res.status(400).json({ message: "Only PDF files are supported" });
      }

      // Extract text
      const buffer = req.file.buffer;
      const data = await pdfParse(buffer);
      const text = data.text;

      // Store metadata
      await storage.createDocument({ filename: req.file.originalname });
      
      // Store text for search
      storage.addDocumentText(req.file.originalname, text);

      res.status(200).json({ message: "File processed successfully", filename: req.file.originalname });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Failed to process file" });
    }
  });

  // Query endpoint
  app.post(api.query.path, async (req, res) => {
    try {
      const { question } = api.query.input.parse(req.body);
      
      const results = await storage.searchDocuments(question);
      
      let answer = "";
      if (results.length === 0) {
        answer = "I couldn't find any relevant information in the uploaded documents.";
      } else {
        answer = `Based on the documents, here is what I found regarding "${question}":\n\n` + 
                 results.map(r => `...${r.text}`).join("\n\n");
      }

      const sources = results.map(r => r.source);
      
      res.status(200).json({ answer, sources });
    } catch (err) {
      if (err instanceof z.ZodError) {
          return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Failed to generate answer" });
    }
  });

  // List documents
  app.get(api.documents.path, async (req, res) => {
    const docs = await storage.getDocuments();
    res.json(docs.map(d => ({ filename: d.filename, processed: d.processed || false })));
  });

  return httpServer;
}
